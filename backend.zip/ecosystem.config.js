module.exports = {
  apps: [
    {
      name: "nectar-be",
      script: "./server.js",
      instances: "max",
      exec_mode: "cluster",
      exp_backoff_restart_delay: 100,
    },
    // {
    //   name: "cronserver",
    //   script: "./cron/cronserver.js",
    //   exec_mode: "cluster_mode",
    //   instances: 1,
    // },
  ],
};
